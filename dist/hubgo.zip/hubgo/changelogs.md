Versão 2.0.0 (25/02/2026)
* Correção de compatibilidade com Melhor Envio
* Otimizações
* Mudança de arquitetura para MACI (Modular Autoload Class Initialization)

Versão 1.4.0 (11/08/2025)
* Correção de bug
    - Carregamento de opções de frete

Versão 1.3.0 (16/02/2024)
* Correção de bugs
* Otimizações
* Novo recurso adicionado: Ativar cálculo automático de frete

Versão 1.2.6 (18/12/2023)
* Correção de bugs

Versão 1.2.5 (31/10/2023)
* Compatibilidade com High Performance Order Storage (HPOS) do WooCommerce

Versão 1.2.0 (09/10/2023)
* Correção de bugs
* Otimizações

Versão 1.1.7 (26/07/2023)
* Correção de bugs
* Otimizações

Versão 1.1.5 (19/07/2023)
* Correção de bugs

Versão 1.1.0 (14/07/2023)
* Correção de bugs

Versão 1.0.0 (13/07/2023)
* Versão inicial