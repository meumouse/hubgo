<?php

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit; }


/**
 * Class for handle requests in shipping calculator
 * 
 * @since 1.0.0
 * @package MeuMouse.com
 */
class Hubgo_Shipping_Management_Shipping_Calculator {

    public function __construct() {
		// instance Hubgo_Shipping_Management_Autoloader class
		$settings = new Hubgo_Shipping_Management_Autoloader();

        add_action( 'wp_ajax_hubgo_ajax_postcode', array( $this,'hubgo_ajax_postcode' ) );
		add_action( 'wp_ajax_nopriv_hubgo_ajax_postcode', array( $this,'hubgo_ajax_postcode' ) );
		add_action( 'wp_enqueue_scripts', array( $this,'enqueue_scripts' ) );
		
		if( $settings->getSetting( 'hook_display_shipping_calculator' ) == 'after_cart' ) {
			add_action( 'woocommerce_product_meta_end', array( $this, 'hubgo_form_shipping_calc' ), 10 );
		} elseif( $settings->getSetting( 'hook_display_shipping_calculator' ) == 'before_cart' ) {
			add_action( 'woocommerce_before_add_to_cart_form', array( $this, 'hubgo_form_shipping_calc' ), 10 );
		} else {
			add_shortcode( 'hubgo_shipping_calculator', array( $this, 'hubgo_form_shipping_calc' ) );
		}
	}


	/**
	 * Enqueue scripts on front-end
	 * 
	 * @since 1.0.0
	 * @return void
	 * @package MeuMouse.com
	 */
	public function enqueue_scripts() {
		$version = Hubgo_Shipping_Management()->version;
		wp_enqueue_script( 'hubgo-shipping-calc', HUBGO_SHIPPING_MANAGEMENT_DIR . 'assets/js/hubgo-shipping-calculator.js', array('jquery'), $version );

		wp_localize_script( 'hubgo-shipping-calc', 'hubgo_params', array(
			'ajaxUrl' => admin_url( 'admin-ajax.php' )
		));
	}


	/**
	 * Call AJAX from front-end form
	 * 
	 * @since 1.0.0
	 * @return void
	 * @package MeuMouse.com
	 */
    public function hubgo_ajax_postcode() {
		check_ajax_referer( 'hubgo-nonce', 'nonce' );

		$data = $_POST;
		$shipping_response = $this->get_product_shipping_estimate( $data );
		$settings = new Hubgo_Shipping_Management_Autoloader();

		if( !is_array( $shipping_response ) ) {
			echo "<div class='woocommerce-message woocommerce-error'>".( $shipping_response ? $shipping_response : __('Nenhuma forma de entrega disponível.', 'hubgo-shipping-management-wc' ) )."</div>";
			
		} else {
			echo '<table cellspacing="0"  class="hubgo-table-shipping-methods shop_table shop_table_responsive">
				<tbody>
					<tr class="hubgo-shipping-header">
				 		<th>'. $settings->getSetting( 'text_header_ship' ) .'</th>
						<th>'. $settings->getSetting( 'text_header_value' ) .'</th>
				  	</tr>';

			foreach ( $shipping_response as $key => $shipping ) {
				echo '<tr class="hubgo-shipping-method">	
						<td>'. $shipping->label .'</td>
						<td>'. wc_price( $shipping->cost ) .'</td>
					</tr>';
			}

			if( !empty( $settings->getSetting( 'note_text_bottom_shipping_calc' ) ) ) {
				echo '<tr class="hubgo-shipping-bottom"><td colspan="2">';
					echo '<span>'. $settings->getSetting( 'note_text_bottom_shipping_calc' ) .'</span>';
				echo '</td></tr>';
			}
			
			
			echo '</tbody> </table>';
		}

		wp_die();
	}


	/**
	 * Get shipping estimate date
	 * 
	 * @since 1.0.0
	 * @return string
	 * @package MeuMouse.com
	 */
	public function get_product_shipping_estimate( array $request ) {
	    $product = wc_get_product( sanitize_text_field( $request['product'] ) );
	    
	    if ( !$product->needs_shipping() || get_option('woocommerce_calc_shipping') === 'no' ) {
			return __('Não foi possível calcular a entrega deste produto', 'hubgo-shipping-management-wc');
		}
		
		if ( !$product->is_in_stock() ) {
			return __('Não foi possível calcular a entrega deste produto, pois o mesmo não está disponível.', 'hubgo-shipping-management-wc');
		}
		
		if (!WC_Validation::is_postcode($request['postcode'], WC()->customer->get_shipping_country())) {
			return __('Por favor, insira um CEP válido.', 'hubgo-shipping-management-wc');
		}
		
		$products = [$product];		

	    if ( WC()->customer->get_shipping_country() ) {
	        $destination = array(
				'country'   => WC()->customer->get_shipping_country(),
				'state'     => WC()->customer->get_shipping_state(),
				'postcode'  => sanitize_text_field( $request['postcode'] ),
				'city'      => WC()->customer->get_shipping_city(),
				'address'   => WC()->customer->get_shipping_address(),
				'address_2' => WC()->customer->get_shipping_address_2()
			);			
	    }
		
		if ( WC()->customer->get_billing_country() ) {
	        $destination = array(
				'country'   => WC()->customer->get_billing_country(),
				'state'     => WC()->customer->get_billing_state(),
				'postcode'  => sanitize_text_field( $request['postcode'] ),
				'city'      => WC()->customer->get_billing_city(),
				'address'   => WC()->customer->get_billing_address(),
				'address_2' => WC()->customer->get_billing_address_2()
			);

	    } else {
	        $destination = wc_get_customer_default_location();
	    }

		$package = array(
			'destination'      => $destination,
			'applied_coupons'  => WC()->cart->get_applied_coupons(),
			'user'             => array('ID' => get_current_user_id())
		);

	    foreach ( $products as $data ) {
	        $cartId = WC()->cart->generate_cart_id( $data->get_id(), $product->is_type('variable') ? $data->variation_id : 0 );
	        $price = wc_get_price_excluding_tax( $data );
	        $tax = wc_get_price_including_tax( $data );

	        $package['contents'] = array(
				$cartId => array(
					'product_id'         => $data->get_id(),
					'data'               => $data,
					'quantity'           => sanitize_text_field( $request['qty'] ),
					'line_total'         => $price,
					'line_tax'           => $tax,
					'line_subtotal'      => $price,
					'line_subtotal_tax'  => $tax,
					'contents_cost'      => $price,
				)
			);

	        if( class_exists('WC_Correios_Webservice') ):

				add_filter( 'woocommerce_correios_shipping_args', function( $array, $this_id, $this_instance_id, $this_package ) use ( $price ) {
					
					$option_id = 'woocommerce_'. $this_id .'_'. $this_instance_id .'_settings';
					$settings = get_option( $option_id );

					if( 'yes' == $settings['declare_value'] ) {
						$array['nVlValorDeclarado'] = $price;
					}

					return $array;
				
				}, 10, 4 ); 

			endif;
		    
		$methods = WC_Shipping::instance()->load_shipping_methods( $package );

	        foreach ($methods as $key => $method) {
	        	
	        	if( "free_shipping" == $method->id && 'yes' == $method->enabled ) {

	        		$GLOBALS['method'] = $method;
	        		$has_coupon = $has_met_min_amount = false;

	        		if ( in_array( $method->requires, array( 'coupon', 'either', 'both' ) ) ) {

			            if ( $coupons = WC()->cart->get_coupons() ) {

			                foreach ( $coupons as $code => $coupon ) {
			                    if ( $coupon->is_valid() && $coupon->get_free_shipping() ) {
			                        $has_coupon = true;
			                        break;
			                    }
			                }
			            }
			        }

			        if ( in_array( $method->requires, array( 'min_amount', 'either', 'both' ) ) ) {
			            $_total = $price * $request['qty'];

			            if ( $_total >= $method->min_amount ) {
			                $has_met_min_amount = true;
			            }
			        }

			        switch ( $method->requires ) {
			            case 'min_amount' :
			                $is_available = $has_met_min_amount;
			                break;
			            case 'coupon' :
			                $is_available = $has_coupon;
			                break;
			            case 'both' :
			                $is_available = $has_met_min_amount && $has_coupon;
			                break;
			            case 'either' :
			                $is_available = $has_met_min_amount || $has_coupon;
			                break;
			            default :
			                $is_available = false;
			                break;
			        }

	        		break;
	        	}
	        }


	        if( $is_available ) {
	        	$rates[$method->id] = (object) [
	        		'cost' => 0,
	        		'label' => $method->method_title
	        	];
	        }

	        $packageRates = WC_Shipping::instance()->calculate_shipping_for_package( $package );

	        foreach ( $packageRates['rates'] as $rate ) {
		    	$meta =  $rate->get_meta_data();

	            if( isset( $meta['_delivery_forecast'] ) )
	        	$rate->set_label( $rate->get_label() . " (Entrega em " . $meta['_delivery_forecast'] . " dias úteis)" );

	            $rates[$rate->get_method_id()] = $rate;

	        }

	        if( $rates ){
				WC()->customer->set_shipping_postcode( $request['postcode'] );
				WC()->customer->set_billing_postcode( $request['postcode'] );
			}
	    }

	    return $rates;
	}


	/**
	 * Form shipping calculator
	 * 
	 * @since 1.0.0
	 * @return void
	 * @package MeuMouse.com
	 */
	public function hubgo_form_shipping_calc() {
		$settings = new Hubgo_Shipping_Management_Autoloader();

		echo '<div id="hubgo-shipping-calc">
		<span class="hubgo-info-shipping-calc">'. $settings->getSetting( 'text_info_before_input_shipping_calc' ) .'</span>
		
		<div class="hubgo-form-group">
			<input id="hubgo-postcode" placeholder="'. $settings->getSetting( 'text_placeholder_input_shipping_calc' ) .'" name="hubgo-postcode">
			<button id="hubgo-shipping-calc-button" disabled>
				<span class="hubgo-shipping-calc-button-title">'. $settings->getSetting( 'text_button_shipping_calc' ) .'</span>
			</button>
		</div>
		
		<a class="hubgo-postcode-search" href="https://buscacepinter.correios.com.br/app/endereco/" target="_blank">'. esc_html__( 'Não sei meu CEP', 'hubgo-shipping-management-wc' ) .'</a>
		
		<input type="hidden" name="hubgo-nonce" id="hubgo-nonce" value="'. wp_create_nonce( 'hubgo-nonce' ) .'"/>
		<input type="hidden" name="add-to-cart" value="<?= get_the_ID() ?>">
		<div id="hubgo-response"></div>
		</div>';
	}
}

new Hubgo_Shipping_Management_Shipping_Calculator();