<?php

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit; }

/**
 * Main class autoloader
 * 
 * @package MeuMouse.com
 * @version 1.0.0
 */
class Hubgo_Shipping_Management_Autoloader {

	public $hubgo_shipping_management_wc_settings = array();
  
  public function __construct() {
    // load plugin setting
    if( empty( $this->hubgo_shipping_management_wc_settings ) ) {
      $this->hubgo_shipping_management_wc_settings = get_option( 'hubgo-shipping-management-wc-setting' );
    }

    add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_front_scripts' ) );

    $options = get_option( 'hubgo-shipping-management-wc-setting' );

    include_once HUBGO_SHIPPING_MANAGEMENT_DIR . 'includes/classes/class-hubgo-shipping-management-custom-colors.php';
    
    // load shipping calculator in single product page
    if( isset( $options['enable_shipping_calculator'] ) == 'yes' ) {
      add_action( 'wp_enqueue_scripts', array( $this, 'hubgo_enqueue_shipping_calculator_scripts' ) );
      include_once HUBGO_SHIPPING_MANAGEMENT_DIR . 'includes/classes/class-hubgo-shipping-management-wc-shipping-calculator.php';
    }
  }


  /**
	 * Plugin default settings for texts
   * 
	 * @return array
	 * @since 1.0.0
	 * @access public
	 */
	public $default_settings = array(
    'primary_main_color' => '#008aff',
    'hook_display_shipping_calculator' => 'after_cart',
    'text_info_before_input_shipping_calc' => 'Consultar prazo e valor da entrega',
    'text_button_shipping_calc' => 'Calcular',
    'text_header_ship' => 'Entrega',
    'text_header_value' => 'Valor',
    'note_text_bottom_shipping_calc' => '*Este resultado é apenas uma estimativa para este produto. O valor final considerado, deverá ser o total do carrinho.',
    'text_placeholder_input_shipping_calc' => 'Informe seu CEP',
  );

  
  /**
	 * Function for get plugin general settings
	 * 
	 * @return string 
	 * @since 1.0.0
	 * @access public
	 */
	public function getSetting( $key ) {
    if( ! empty( $this->hubgo_shipping_management_wc_settings) && isset( $this->hubgo_shipping_management_wc_settings[ $key ] ) ) {
      return $this->hubgo_shipping_management_wc_settings[ $key ];
    }

    if( isset( $this->default_settings[ $key ] ) ) {
      return $this->default_settings[ $key ];
    }

    return false;
  }

  /**
   * Load scripts in front-end
   * 
   * @since 1.0.0
   * @return void
   */
  public function enqueue_front_scripts() {
    $version = Hubgo_Shipping_Management()->version;

    wp_enqueue_style( 'hubgo-shipping-management-wc-front-styles', HUBGO_SHIPPING_MANAGEMENT_URL . 'assets/css/hubgo-shipping-management-wc-front-styles.css', array(), $version );
    wp_enqueue_script( 'hubgo-shipping-management-wc-front-scripts', HUBGO_SHIPPING_MANAGEMENT_URL . 'assets/js/hubgo-shipping-management-wc-front-scripts.js', array('jquery'), $version );

  }

  /**
   * Load shipping calculator scripts
   * 
   * @since 1.0.0
   * @return void
   * @package MeuMouse.com
   */
  public function hubgo_enqueue_shipping_calculator_scripts() {
    $version = Hubgo_Shipping_Management()->version;
    $options = get_option( 'hubgo-shipping-management-wc-setting' );

    wp_enqueue_script( 'hubgo-shipping-calculator-scripts', HUBGO_SHIPPING_MANAGEMENT_URL . 'assets/js/hubgo-shipping-calculator.js', array('jquery'), $version );

    wp_localize_script( 'hubgo-shipping-calculator-scripts', 'hubgo_params', array(
      'ajaxUrl' => admin_url( 'admin-ajax.php' ),
      'enabled_detect_variation' => $options['enable_require_select_variation'] == 'yes',
    ) );
  }

}

new Hubgo_Shipping_Management_Autoloader();