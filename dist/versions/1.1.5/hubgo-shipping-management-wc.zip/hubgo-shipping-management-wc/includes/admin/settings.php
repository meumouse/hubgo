<?php

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit; } ?>

<div class="d-flex">
    <h1 class="hubgo-shipping-management-wc-admin-section-tile"><?php echo get_admin_page_title() ?></h1>
</div>

<div class="hubgo-shipping-management-wc-admin-title-description">
    <p><?php echo esc_html__( 'Extensão que permite gerenciar opções de frete para lojas WooCommerce. Se precisar de ajuda para configurar, acesse nossa', 'hubgo-shipping-management-wc' ) ?>
        <a class="fancy-link" href="https://meumouse.com/docs/plugins/hubgo/" target="_blank"><?php echo esc_html__( 'Central de ajuda', 'hubgo-shipping-management-wc' ) ?></a>
    </p>
</div>

<?php

    if( $settingSaves === true) { ?>
        <div class="toast update-notice-spm-wp">
            <div class="toast-header bg-success text-white">
                <i class="fa-regular fa-circle-check me-3"></i>
                <span class="me-auto"><?php _e( 'Salvo com sucesso', 'hubgo-shipping-management-wc' ); ?></span>
                <button class="btn-close btn-close-white ms-2 hide-toast" type="button" data-bs-dismiss="toast" aria-label="Close"></button>
            </div>
            <div class="toast-body"><?php _e( 'As configurações foram atualizadas!', 'hubgo-shipping-management-wc' ); ?></div>
        </div>
        <?php
    }

    settings_errors(); ?>

<div class="hubgo-shipping-management-wc-wrapper">
    <form method="post" action="" class="hubgo-shipping-management-wc-form" name="hubgo-shipping-management-wc">
        <input type="hidden" name="hubgo-shipping-management-wc" value="1"/>
        <?php
        include_once HUBGO_SHIPPING_MANAGEMENT_DIR . 'includes/admin/options.php';
        ?>
        <button id="save_settings" name="save_settings" class="btn btn-primary m-5 button-loading" type="submit">
            <span class="span-inside-button-loader"><?php esc_attr_e( 'Salvar alterações', 'hubgo-shipping-management-wc' ); ?></span>
        </button>
    </form>
</div>