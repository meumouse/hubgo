Versão 2.2.0 (12/03/2026)
* Correção de bugs:
    -Pedidos com status 'Pedido enviado' não são exibidos na página de pedidos.
* Recurso adicionado: Status de 'Pedido enviado' nas ações em massa da página de pedidos

Versão 2.1.0 (06/03/2026)
* Recurso adicionado: Novo status de pedido -> Pedido enviado
* Recurso adicionado: Meta box para cadastro de código de rastreio no pedido
* Recurso adicionado: Integração com Joinotify

Versão 2.0.0 (25/02/2026)
* Correção de compatibilidade com Melhor Envio
* Otimizações
* Mudança de arquitetura para MACI (Modular Autoload Class Initialization)

Versão 1.4.0 (11/08/2025)
* Correção de bug
    - Carregamento de opções de frete

Versão 1.3.0 (16/02/2024)
* Correção de bugs
* Otimizações
* Novo recurso adicionado: Ativar cálculo automático de frete

Versão 1.2.6 (18/12/2023)
* Correção de bugs

Versão 1.2.5 (31/10/2023)
* Compatibilidade com High Performance Order Storage (HPOS) do WooCommerce

Versão 1.2.0 (09/10/2023)
* Correção de bugs
* Otimizações

Versão 1.1.7 (26/07/2023)
* Correção de bugs
* Otimizações

Versão 1.1.5 (19/07/2023)
* Correção de bugs

Versão 1.1.0 (14/07/2023)
* Correção de bugs

Versão 1.0.0 (13/07/2023)
* Versão inicial