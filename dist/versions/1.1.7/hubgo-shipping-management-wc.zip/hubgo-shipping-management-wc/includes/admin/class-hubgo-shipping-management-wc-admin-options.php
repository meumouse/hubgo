<?php

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
  exit; }

class Hubgo_Shipping_Management_Admin_Options extends Hubgo_Shipping_Management_Autoloader {

  /**
   * Hubgo_Shipping_Management_Admin constructor.
   *
   * @since 1.0.0
   * @access public
   */
  public function __construct() {
    parent::__construct();

    add_action( 'admin_menu', array( $this, 'hubgo_shipping_management_wc_admin_menu' ) );
    add_action( 'admin_enqueue_scripts', array( $this, 'hubgo_shipping_management_wc_admin_scripts' ) );
  }

  /**
   * Function for create submenu in settings
   * 
   * @since 1.0.0
   * @access public
   * @return array
   */
  public function hubgo_shipping_management_wc_admin_menu() {
    add_submenu_page(
      'woocommerce', // parent page slug
      esc_html__( 'HubGo - Gerenciamento de Frete para WooCommerce', 'hubgo-shipping-management-wc'), // page title
      esc_html__( 'HubGo', 'hubgo-shipping-management-wc'), // submenu title
      'manage_woocommerce', // user capabilities
      'hubgo-shipping-management-wc', // page slug
      array( $this, 'hubgo_shipping_management_wc_settings_page' ) // public function for print content page
    );
  }


  /**
   * Plugin general setting page and save options
   * 
   * @since 1.0.0
   * @access public
   */
  public function hubgo_shipping_management_wc_settings_page() {
    $settingSaves = false;

    // Save global options
    if( current_user_can( 'manage_options' ) && isset( $_POST[ 'save_settings' ] ) ) {
      update_option( 'hubgo-shipping-management-wc-setting', $_POST );
      $this->hubgo_shipping_management_wc_settings = $_POST;

      $settingSaves = true;
    }

    $options = get_option( 'hubgo-shipping-management-wc-setting' );

    include_once HUBGO_SHIPPING_MANAGEMENT_DIR . 'includes/admin/settings.php';
  }


  /**
   * Enqueue admin scripts in page settings only
   * 
   * @since 1.0.0
   * @access public
   * @return void
   */
  public function hubgo_shipping_management_wc_admin_scripts() {
    $url = $_SERVER['SERVER_NAME'] . $_SERVER['REQUEST_URI'];
    $version = Hubgo_Shipping_Management()->version;
    
    if ( false !== strpos( $url, 'admin.php?page=hubgo-shipping-management-wc' ) ) {
      wp_enqueue_script( 'hubgo-shipping-management-wc-admin-scripts', HUBGO_SHIPPING_MANAGEMENT_URL . 'assets/js/hubgo-shipping-management-wc-admin-scripts.js', array('jquery'), $version );
      wp_enqueue_style( 'hubgo-shipping-management-wc-admin-styles', HUBGO_SHIPPING_MANAGEMENT_URL . 'assets/css/hubgo-shipping-management-wc-admin-styles.css', array(), $version );
    }
  }

}

new Hubgo_Shipping_Management_Admin_Options();